<?php

require_once '../app/Database.php';
require_once 'PHPUnit.php';

### TODO: http://there4development.com/blog/2013/10/13/unit-testing-slim-framework-applications-with-phpunit/

class GeofierDatabaseTest extends PHPUnit_TestCase {

    var $db;

    function GeofierDatabaseTest($name){
        $this->PHPUnit_TestCase($name);
    }

    function setUp(){
        $this->db = new Database();
    }

    function tearDown(){
        unset($this->db);
    }

    function testFilterID() {
        $expected_id455 = '{"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"Point","coordinates":[-7.8331148782063,43.455328225072]},"properties":{"idestacion":455,"nombre":"EUME_RIBEIRA","lugar":"RIBEIRANOVA","idmunicipi":15070,"idparroqui":1507005,"xutm":594409,"yutm":4812220,"idsistexpl":13,"supconcato":470,"supconcave":190.6}}]}';
                
    }
}

?>

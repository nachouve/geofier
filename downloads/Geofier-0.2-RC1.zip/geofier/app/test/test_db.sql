INSERT INTO "aforos" VALUES(1,431,'MASMA','MASMA',27030,2703005,634725,4815300,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; 1/10/1990_ actualidade

CARACTERÍSTICAS DA SECCIÓN
Sección de pouco calado, delimitada pola estrutura da  ponte donde está localizado o punto de medida. Está situada  nun tramo recto do río ainda que con abu',18,291.34,145.27);
INSERT INTO "aforos" VALUES(2,433,'OURO','SAN ACISCLO',27019,2701907,631158,4824170,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; 1/10/1990_ actualidade

Sección coincidente coa estrutura dunha antiga ponte de pedra. O canle ten pouco calado e posúe un leito uniforme, ainda que areoso. Non hai presenza de vexetación destacable.									',17,188.9,162.6);
INSERT INTO "aforos" VALUES(3,438,'LANDRO','CHAVÍN',27066,2706611,613777,4830660,'SERIE HISTÓRICA_  Oct 1975-Sep 1987; 1/10/1990_ actualidade

Aproximación prácticamente recta bastante rápida con sección uniforme en principio pouco apropiada. Doble control hidráulico (sección sensible e normal) con vertedoiros e muros verticales de',17,269.6,198.0);
INSERT INTO "aforos" VALUES(4,440,'SOR','PTE.SEGADE (MAÑÓN)',15044,1504403,602299,4830530,'SERIE HISTÓRICA_ 1/10/1970-30/09/1987; Xaneiro 1997-Setembro 2002; Outubro 2004_ actualidade

Aproximación recta, con gran calado na zona de augas arriba. Sección de control uns 50 m. augas abaixo creando un importante remanso. Destacar que en 2003 rea',16,201.79,121.13);
INSERT INTO "aforos" VALUES(5,443,'MERA','SANTA MARÍA DE MERA',15061,1506118,588135,4832610,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; 1/10/1990_ actualidade

Aproximación cunha lixeira curva. Control hidráulico natural augas abaixo da estación. Sección natural relativamente estable. Escala adosada a tubo tranquilizador.',15,126.99,102.2);
INSERT INTO "aforos" VALUES(6,446,'XUBIA','SAN SADURNIÑO',15076,1507607,574583,4820580,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1985 ; 1/10/1990_ actualidade

Uns 30 m. debaixo dunha dobre ponte e curva á dereita que sen dúbida darán lugar a fluxos secundarios. Control hidráulico para caudais baixos mediante estructura (vertedero simple). Pe',14,182.4,108.26);
INSERT INTO "aforos" VALUES(7,464,'MANDEO','MUÑIFERAL',15039,1503906,576732,4789040,'Serie histórica Oct. 1970-Sept. 1986; Outubro1990-Actualidade 

Aproximación prácticamente recta con sección bastante uniforme. Control hidráulico inmediatamente augas abaixo da ponte, que crea un importante remanso. A sección divídese en dous tramos i',12,456.97,248.21);
INSERT INTO "aforos" VALUES(8,485,'ANLLÓNS','ANLLÓNS',15068,1506801,509315,4786330,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; 1/10/1990_ actualidade

Sección estable aunque de batimetría algo irregular do cauce protexida por un pequeno encauzamento contando co remanso provocado por unha ponte situada sobre unha sección de control. E',10,516.36,438.2);
INSERT INTO "aforos" VALUES(9,520,'TAMBRE','CAROLLO',15060,1506005,549038,4758480,'Datos dende Abril 2002-Setembro 2002; Oct 2004-Actualidade

Sección moi profunda e estable emprazada nun tramo sensiblemente recto do río. Escala adosada en estribo de marxe dereita da ponte. A estación entrou en funcionamiento ó comezo do ano 2002, po',6,1526.17,561.14);
INSERT INTO "aforos" VALUES(10,540,'SAR','VIDALOISO (BASTABALES)',15013,1501302,528855,4742250,'Datos dende Outubro 2004- Actualidade

Estación situada no lateral dunha sección influenciada por unha ponte de varios pilares, que producen turbulencias de certa magnitude. Augas arriba, a escasos metros hai un pequeno embalse que frena o caudal, o ca',5,265.59,61.92);
INSERT INTO "aforos" VALUES(11,564,'UMIA','CALDAS DE REIS',36005,3600503,529333,4717000,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; 1/10/1990- Xullo 2001; Febreiro 2002-Setembro 2002; Outubro 2004- Actualidade

Augas abaixo da ponte en N-550 en tramo recto con sección irregular de escaso calado. Non existe ningún control hidráulico augas',4,446.22,190.0);
INSERT INTO "aforos" VALUES(12,552,'DEZA','PUENTE CIRA',36052,3605201,554315,4736500,'Datos dende Oct. 72-Sept.87; Pct. 90_Actualidade

Zona de gran calado nunha aproximación prácticamente recta. Augas abaixo a uns 150m existe un remanso. A sección e bastante irregular, con zonas de grande calado e zonas de vexetación en augas medias-ba',5,551.0,544.7);
INSERT INTO "aforos" VALUES(13,542,'FURELOS','PUENTE BARAZÓN',15079,1507902,580145,4745740,'Datos dende Oct. 90-Actualidade

Aproximación recta. Sección uniforme.',5,151.6,150.0);
INSERT INTO "aforos" VALUES(14,544,'ULLA','A PONTE NOVA',15079,1507901,579762,4744480,'Aproximación en curva lixeira á esquerda. Control hidráulico creado por aterramento na ponte. Sección estable. Uniformidad do fluxo destruida pola construcción da nova ponte. A estación está soportada sobre un pilar da propipa ponte, co que as súas medid',5,2803.67,515.72);
INSERT INTO "aforos" VALUES(15,568,'BAIXO UMIA','A FIGUEIRA',36046,3604604,519383,4707240,'Datos dende Feb. 2009

Sección influenciada polos pilares da ponte existente. Este feito  provoca a acumulación de restos vexetais de gran tamaño nas súas aproximacións, aspecto que hai que controlar.',4,446.25,386.31);
INSERT INTO "aforos" VALUES(16,585,'VERDUGO','PONTE-CALDELAS',36043,3604307,541267,4693430,'Datos dende Dec. 2008
Sección bastante estable e regular, con leito  libre de vexetación e perfis de velocidades uniformes ainda que de baixas magnitudes. A presenza de pilares no cauce pode influenciar o comportamento do caudal en augas altas.',1,333.46,102.54);
INSERT INTO "aforos" VALUES(17,554,'ULLA_TEO','PONTEVEA',15082,1508209,537137,4734420,'Datos dende Oct. 20080

Sección localizada nun tramo do río de gran anchura e calado. A velocidade  do caudal é pouco  significativo, influenciado pola presencia dunha vella ponte augas abaixo, que provoca un remanso hidráulico natural.',5,2803.68,2291.08);
INSERT INTO "aforos" VALUES(18,550,'ULLA_TOURO','BASEBE',15085,1508513,559623,4741760,'Daots dende Oct. 2008

Sección uniforme de gran calado, nun tramo recto do río.',5,2803.68,308.74);
INSERT INTO "aforos" VALUES(19,546,'ARNEGO_ULLA','PONTE CIRELA',36020,3602011,573583,4736750,'Datos dende Dec. 2008 (Incompletos)

Sección uniforme e estable, delimitada por un muro de formigón pertencente a ponte existente. Non se aprecia existencia de vexetación destacable na canle.',5,0.0,328.18);
INSERT INTO "aforos" VALUES(20,512,'XALLAS 1','A PONTE DE TRUEBE',15077,1507713,509117,4760610,'Datos dende Dec. 2008',7,504.28,200.86);
INSERT INTO "aforos" VALUES(21,497,'GRANDE_CAMARIÑAS','AS CASAS NOVAS',15016,1501603,491181,4776100,'Datos dende Dec. 2008

Sección localizada nun tramo do río próximo á desembocadura. Presenta unha batimetría irregular. As velocidades do caudal son xeralmente altas, e hai  presenza de certa vexetación no leito.',9,282.95,251.02);
INSERT INTO "aforos" VALUES(22,483,'ANLLONS _CARBALLO','CARBALLO',15019,1501907,525085,4784410,'Datos dende Xaneiro 2009

Sección formada totalmente por estrutura de formigón, delimitada por muros verticais a ambos lados. O leito é totalmente regular, e con presenza de pedras de pouca envergadura. Non hai presenza de vexetación',10,516.35,118.46);
INSERT INTO "aforos" VALUES(23,472,'BARCES','A PONTE DA RIBEIRA',15021,1502101,555046,4786320,'',11,83.8,0.0);
INSERT INTO "aforos" VALUES(24,455,'EUME_RIBEIRA','RIBEIRANOVA',15070,1507005,594409,4812220,'Datos dende Xaneiro 2009

Sección situada nun tramo recto do río, estable e uniforme. Sen presenza de vexetación apreciable, e de pouco calado en augas medias-baixas. Cabe destacar que está situado augas abaixo da presa da Ribeira.',13,470.0,190.6);
INSERT INTO "aforos" VALUES(25,449,'BELELLE','A MACIÑEIRA',15055,1505503,570295,4817370,'Datos dende Outubro 2008

Sección de gran calado, con ribeiras de acusada pendente e non fácil acceso. En augas medias altas, as velocidades do caudal son elevadas. Situación próxima á desembocadura													
													
',14,60.11,55.58);
INSERT INTO "aforos" VALUES(26,441,'SOR_BAIXO','O MORGALLÓN',27064,2706403,605314,4839870,'Datos dende Outubro 2008

"Sección localizada no tramo final do río, cerca da desembocadura. Posue un perfil sen alteracións naturais e de calado destacable. Non hai presenza de vexetación no leito, formado principalmente de rochas. A distribución de v',16,201.85,184.84);
INSERT INTO "aforos" VALUES(27,435,'COVO','O GUIONCHO',27013,2701304,625112,4838280,'Datos dende Decembro 2008

Sección delimitada pola estrutura da ponte existente. A marxe esquerda por un muro de formigón, e a marxe dereita por un pequeño lavadoiro que apenas afecta o comportamento natural do caudal. Pouco calado e leito  regular.			',17,4392.0,4261.0);
INSERT INTO "aforos" VALUES(28,430,'GRANDE_RIBADEO','AS ANZAS',27051,2705106,654952,4818390,'Datos dende Outubro 2008

O cauce pódese considerar estreito, duns dez metros en augas altas. De pouco calado, ainda que sensible ó  desbordamento en épocas de fortes precipitacións. Non hai presenza de vexetación no leito nin remansos apreciables.				',19,6481.0,0.0);
INSERT INTO "aforos" VALUES(29,528,'BARCALA_TAMBRE','NEGREIRA',15056,1505600,521350,4750710,'Datos dende Dec. 2008

A sección pódese considerar como regular e estable. Está delimitada por ambos muros de formigón, pertencentes á estrutura da ponte localizada no punto de medida.',6,0.0,92.42);
INSERT INTO "aforos" VALUES(30,514,'XALLAS 2','A PONTE OLVEIRA',15045,1504508,498629,4756820,'Datos dende Dec. 2008 

Sección bastante ancha e irregular. Augas abaixo da presa de Fervenza.',7,504.28,362.01);
INSERT INTO "aforos" VALUES(31,506,'CASTRO','A PONTE DE CONSTANTE',15023,1502305,484481,4761390,'Datos dende Dec. 2008

Sección localizada nun tramo ancho do río, irregular e influenciado en certa medida pola presenza de abundante vexetación poucos metros augas arriba.',8,140.19,109.48);
INSERT INTO "aforos" VALUES(32,588,'OITAVÉN','O SOBRAL',36053,3605302,536637,4687860,'SERIE HISTÓRICA_ 1/10/1970 ata 30/09/1987 ; Oct. 2008 - Actualidade

Sección localizada augas abaixo dunha curva. Posue un calado destacable tendo en conta as súas dimensións. O leito é irregular con forte presencia de rochas.',1,333.46,177.42);
INSERT INTO "aforos" VALUES(33,470,'MERO','A PONTE DE BEDOÑA',15009,1500902,560447,4789800,'',11,119.67,0.0);
INSERT INTO "aforos" VALUES(34,469,'MENDO','BARALLOBRE',15009,1500901,564942,4790760,'Datos demde Decembro 2008

A sección está localizada nun tramo lixeiramente en curva, pero que apenas ten influencia no comportamento do caudal. É destacable a presenza de vexetación na canle.',12,91.51,83.33);
INSERT INTO "aforos" VALUES(35,578,'LEREZ','O COUSO',36038,3603807,531847,4700260,'Existen datos de la CHN y de la Xunta hasta 1998

Sección ancha e de certo calado, localizada en curva. Augas abaixo, esta localizada unha estrutura de control hidráulico para o abastecemento de auga potable. En épocas de fortes enchentes, poden ocurri',3,449.51,408.49);
INSERT INTO "aforos" VALUES(36,445,'REGO DAS MESTAS','O PORTO DO CABO',15087,1508709,577566,4830880,'Datos dende Outubro 2008
Sección estreita e de pouco calado. Situada nun tramo recto próximo á desembocadura. Leito sen vexetación, proximo a DPMT, en Margen Izqd. de DPH',15,121.98,70.83);
INSERT INTO "aforos" VALUES(37,594,'MIÑOR','A PONTE',36021,3602106,518788,4662290,'Datos dende Oct. 2008

Sección localizada nun tramo recto do río, augas abaixo dunha ponte que divide a canle en dúas. O leito, con certa vexetación, presenta un terreno con forte presencia de áridos.',1,0.0,64.1);
INSERT INTO "aforos" VALUES(38,525,'DUBRA_TAMBRE','A PONTE DE LESTA',15088,1508811,528302,4758360,'Datos dende Dec. 2008 

Sección regular e estable, localizada nun tramo recto do  río. Non ten un calado destacable.',6,0.0,90.67);
INSERT INTO "aforos" VALUES(39,595,'GROVA','BOUZAS',36003,3600306,515127,4661690,'Datos dende Dec. 2008',1,0.0,16.58);
INSERT INTO "aforos" VALUES(40,510,'CEE','ESCABANAS',15023,1502303,484492,4756670,'Datos dende Dec. 2008

A sección está localizada nun tramo estreito e uniforme, delimitado por muros artificiais de pedra, e de pouco calado. O leito é uniforme e  rochoso. En augas altas o caudal sufre rápidas crecidas, poidendo chegar ó desbordamento',7,102.13,5.34);
INSERT INTO "aforos" VALUES(41,458,'EUME_AS FRAGAS','SANTA CRISTINA',15050,1505005,575822,4807480,'Datos dende Xaneiro 2009

Sección localizada en curva, e de leito irregular. A presenza no leito de rochas de gran tamaño pode provocar en augas altas algún resalto.',13,470.0,434.0);
INSERT INTO "aforos" VALUES(42,593,'LAGARES','CARIDE',36057,3605714,525273,4674710,'Datos dende Dec. 2008 

Sección localizada en curva, de escasas dimensións, con presenza de vexetación sobre todo nos laterais do río. En épocas de fortes precipitacións hai desbordamentos na zona.',1,0.0,30.9);
INSERT INTO "aforos" VALUES(43,473,'MERO_A TELVA','A TELVA',15017,1501710,552300,4793920,'',11,0.0,0.0);
INSERT INTO "aforos" VALUES(44,522,'LENGÜELLE_TAMBRE','VILACIDE DE ARRIBA',15060,1506007,544500,4760160,'Datos dende Dec. 2008',6,0.0,311.28);
COMMIT;

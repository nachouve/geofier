# Script to check php code

# pear install PHP_CodeSniffer

phpcs app/config.php
phpcs app/Database.php
phpcs app/Geojson.php
phpcs public_html/index.php

